function Stroke(color, size,type){
	this.color = color;
	this.size = size;
	this.type = type;
	

	this.someFunction = function(){
		return(this.color);
	}




}